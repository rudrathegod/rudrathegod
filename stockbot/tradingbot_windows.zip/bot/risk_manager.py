"""Risk management: position sizing, stops, correlation filter, drawdown breaker.

This module is intentionally pure/stateless (aside from the peak-equity tracker)
so it behaves identically live and in backtests.
"""
from __future__ import annotations

from typing import Optional

from config import (
    CORRELATION_FILTER,
    MAX_PORTFOLIO_DRAWDOWN,
    MAX_POSITION_NOTIONAL_PCT,
    MIN_STOP_DISTANCE_PCT,
    RISK_PER_TRADE,
)
from .signals import Action, Position, Signal


def position_size(equity: float, signal: Signal, allow_fractional: bool) -> float:
    """Size a position so that a move of `stop_distance` against us == RISK_PER_TRADE of equity.

    qty = (equity * risk%) / stop_distance_per_unit

    Two guards keep this sane on short timeframes where ATR is tiny:
    1. The stop distance is floored at MIN_STOP_DISTANCE_PCT of price.
    2. The resulting notional (qty * price) is capped at MAX_POSITION_NOTIONAL_PCT
       of equity, so a single order can never blow past buying power.

    Equities are rounded down to whole shares; crypto allows fractional units.
    """
    if signal.stop_distance <= 0 or equity <= 0 or signal.price <= 0:
        return 0.0
    # Guard 1: don't let a noise-level (tiny) stop distance explode the size.
    stop_distance = max(signal.stop_distance, signal.price * MIN_STOP_DISTANCE_PCT)
    risk_dollars = equity * RISK_PER_TRADE
    qty = risk_dollars / stop_distance
    # Guard 2: hard cap on position notional as a fraction of equity.
    max_qty_by_notional = (equity * MAX_POSITION_NOTIONAL_PCT) / signal.price
    qty = min(qty, max_qty_by_notional)
    if not allow_fractional:
        qty = float(int(qty))  # floor to whole shares
    return max(qty, 0.0)


def stop_price_for(signal: Signal) -> float:
    """Initial hard stop price, `stop_distance` away from entry in the adverse direction."""
    if signal.action == Action.LONG:
        return signal.price - signal.stop_distance
    if signal.action == Action.SHORT:
        return signal.price + signal.stop_distance
    return 0.0


def passes_correlation_filter(
    signal: Signal, open_positions: dict[str, Position]
) -> bool:
    """Return False if opening this signal would violate a correlation rule.

    Rule (risk_on): if all trigger symbols are already long, block new LONGs on
    the blocked symbols.
    """
    if signal.action != Action.LONG:
        return True
    for rule in CORRELATION_FILTER.values():
        if signal.symbol not in rule["block"]:
            continue
        triggers = rule["trigger"]
        all_triggers_long = all(
            sym in open_positions and open_positions[sym].side == "long"
            for sym in triggers
        )
        if all_triggers_long:
            return False
    return True


class DrawdownGuard:
    """Tracks peak equity and trips a circuit breaker on excessive drawdown."""

    def __init__(self, starting_equity: float):
        self.peak = starting_equity
        self.tripped = False

    def update(self, equity: float) -> None:
        if equity > self.peak:
            self.peak = equity

    def drawdown(self, equity: float) -> float:
        if self.peak <= 0:
            return 0.0
        return (self.peak - equity) / self.peak

    def check(self, equity: float) -> bool:
        """Update peak and return True if the breaker is (now) tripped."""
        self.update(equity)
        if self.drawdown(equity) >= MAX_PORTFOLIO_DRAWDOWN:
            self.tripped = True
        return self.tripped


def stop_hit(position: Position, high: float, low: float) -> bool:
    """Whether the hard stop was breached by this bar's range."""
    if position.side == "long":
        return low <= position.stop_price
    return high >= position.stop_price


def update_trailing_stop(
    position: Position, high: float, low: float, current_atr: float, trail_mult: float
) -> None:
    """Ratchet the stop in the favorable direction only (never widened)."""
    if trail_mult <= 0 or current_atr <= 0:
        return
    if position.side == "long":
        position.high_water = max(position.high_water, high)
        new_stop = position.high_water - trail_mult * current_atr
        position.stop_price = max(position.stop_price, new_stop)
    else:
        position.high_water = min(position.high_water, low)
        new_stop = position.high_water + trail_mult * current_atr
        position.stop_price = min(position.stop_price, new_stop)
