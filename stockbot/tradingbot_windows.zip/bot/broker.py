"""Thin wrapper around Alpaca's TradingClient for order execution and account state.

Keeps the rest of the bot decoupled from alpaca-py specifics and makes the
paper/live safety lock impossible to bypass.
"""
from __future__ import annotations

from typing import Optional

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import OrderSide, TimeInForce
from alpaca.trading.requests import MarketOrderRequest

from config import (
    ALLOW_LIVE,
    ALPACA_API_KEY,
    ALPACA_SECRET_KEY,
    IS_PAPER,
    validate_credentials,
)
from .signals import Position


class Broker:
    def __init__(self) -> None:
        validate_credentials()
        self.client = TradingClient(
            ALPACA_API_KEY, ALPACA_SECRET_KEY, paper=IS_PAPER
        )
        self.is_paper = IS_PAPER
        if not IS_PAPER and not ALLOW_LIVE:
            # Defense in depth; validate_credentials already covers this.
            raise RuntimeError("Live trading blocked (ALLOW_LIVE != true).")

    # -- account --------------------------------------------------------------
    def equity(self) -> float:
        return float(self.client.get_account().equity)

    def cash(self) -> float:
        return float(self.client.get_account().cash)

    # -- positions ------------------------------------------------------------
    def open_positions(self) -> dict[str, Position]:
        result: dict[str, Position] = {}
        for p in self.client.get_all_positions():
            side = "long" if float(p.qty) > 0 else "short"
            entry = float(p.avg_entry_price)
            result[_from_alpaca_symbol(p.symbol)] = Position(
                symbol=_from_alpaca_symbol(p.symbol),
                side=side,
                qty=abs(float(p.qty)),
                entry_price=entry,
                stop_price=0.0,       # broker doesn't track our logical stop
                high_water=entry,
                entry_atr=0.0,
            )
        return result

    def get_position(self, symbol: str) -> Optional[Position]:
        return self.open_positions().get(symbol)

    # -- orders ---------------------------------------------------------------
    def submit_market_order(self, symbol: str, qty: float, side: str) -> object:
        order_side = OrderSide.BUY if side == "buy" else OrderSide.SELL
        # Crypto trades 24/7 and requires GTC; equities use DAY.
        tif = TimeInForce.GTC if "/" in symbol else TimeInForce.DAY
        req = MarketOrderRequest(
            symbol=_to_alpaca_symbol(symbol),
            qty=qty,
            side=order_side,
            time_in_force=tif,
        )
        return self.client.submit_order(req)

    def close_position(self, symbol: str) -> object:
        return self.client.close_position(_to_alpaca_symbol(symbol))

    def close_all(self) -> None:
        self.client.close_all_positions(cancel_orders=True)

    # -- market clock ---------------------------------------------------------
    def is_equity_market_open(self) -> bool:
        return bool(self.client.get_clock().is_open)


def _to_alpaca_symbol(symbol: str) -> str:
    # alpaca-py trading uses "BTC/USD" for crypto already; equities unchanged.
    return symbol


def _from_alpaca_symbol(symbol: str) -> str:
    # Positions API may return "BTCUSD" for crypto; normalize back to slash form.
    if symbol.endswith("USD") and "/" not in symbol and len(symbol) > 3:
        base = symbol[:-3]
        if base in {"BTC", "ETH", "LTC", "BCH"}:
            return f"{base}/USD"
    return symbol
