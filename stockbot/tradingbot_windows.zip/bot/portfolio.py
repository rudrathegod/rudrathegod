"""Portfolio state manager.

Bridges strategy signals and the broker: opens/closes positions, tracks the
logical stop and high-water mark for each open position (the broker doesn't
store these), and writes trade logs.
"""
from __future__ import annotations

from typing import Optional

from . import risk_manager as rm
from .broker import Broker
from .logger import log_trade
from .signals import Action, Position, Signal


class Portfolio:
    def __init__(self, broker: Broker):
        self.broker = broker
        # Our logical view of positions, keyed by symbol. Seeded from the broker
        # so restarts don't lose track of open trades (stops re-derived below).
        self.positions: dict[str, Position] = broker.open_positions()

    # -- queries --------------------------------------------------------------
    def get(self, symbol: str) -> Optional[Position]:
        return self.positions.get(symbol)

    def equity(self) -> float:
        return self.broker.equity()

    # -- mutations ------------------------------------------------------------
    def open(self, signal: Signal, qty: float, allow_fractional: bool) -> bool:
        if qty <= 0:
            return False
        side = "long" if signal.action == Action.LONG else "short"
        order_side = "buy" if side == "long" else "sell"
        self.broker.submit_market_order(signal.symbol, qty, order_side)

        stop = rm.stop_price_for(signal)
        self.positions[signal.symbol] = Position(
            symbol=signal.symbol,
            side=side,
            qty=qty,
            entry_price=signal.price,
            stop_price=stop,
            high_water=signal.price,
            entry_atr=signal.atr,
        )
        log_trade(
            instrument=signal.symbol,
            direction=side,
            entry_price=signal.price,
            exit_price=None,
            profit_loss=None,
            position_size=qty,
            reason=f"ENTRY: {signal.reason}",
        )
        return True

    def close(self, symbol: str, exit_price: float, reason: str) -> None:
        pos = self.positions.get(symbol)
        if pos is None:
            return
        self.broker.close_position(symbol)
        pnl = self._pnl(pos, exit_price)
        log_trade(
            instrument=symbol,
            direction=f"exit_{pos.side}",
            entry_price=pos.entry_price,
            exit_price=exit_price,
            profit_loss=pnl,
            position_size=pos.qty,
            reason=f"EXIT: {reason}",
        )
        del self.positions[symbol]

    @staticmethod
    def _pnl(pos: Position, exit_price: float) -> float:
        if pos.side == "long":
            return (exit_price - pos.entry_price) * pos.qty
        return (pos.entry_price - exit_price) * pos.qty
