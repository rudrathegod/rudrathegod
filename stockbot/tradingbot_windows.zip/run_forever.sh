#!/usr/bin/env bash
# 24/7 supervisor for the paper trading bot.
# - Auto-restarts the bot if it crashes (after a short backoff).
# - Does NOT restart if the 10% drawdown circuit breaker tripped (exit code 42),
#   so a halt stays halted until you manually review and relaunch.
# Logs go to logs/bot.out. Start detached with:
#     nohup ./run_forever.sh >/dev/null 2>&1 &
set -u
cd "$(dirname "$0")"
mkdir -p logs

while true; do
  echo "[start $(date -u +%FT%TZ)]" >> logs/bot.out
  MPLCONFIGDIR=/tmp/mpl ./.venv/bin/python -m bot.main >> logs/bot.out 2>&1
  code=$?
  echo "[exit code=$code $(date -u +%FT%TZ)]" >> logs/bot.out

  if [ "$code" -eq 42 ]; then
    echo "[HALT] Drawdown circuit breaker tripped. NOT restarting. Review, then relaunch manually." >> logs/bot.out
    break
  fi
  if [ "$code" -eq 0 ]; then
    echo "[STOP] Clean exit (e.g. Ctrl-C). NOT restarting." >> logs/bot.out
    break
  fi
  echo "[restart] Unexpected exit ($code); restarting in 10s..." >> logs/bot.out
  sleep 10
done
