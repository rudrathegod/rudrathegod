"""Central configuration for the trading bot.

All strategy parameters, instrument mappings, and risk limits live here so the
live bot and the backtester read from a single source of truth.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from dotenv import load_dotenv

load_dotenv()

# ---------------------------------------------------------------------------
# Credentials / environment
# ---------------------------------------------------------------------------
# Accept both this project's names and Alpaca's canonical env vars
# (APCA_API_KEY_ID / APCA_API_SECRET_KEY / APCA_API_BASE_URL) so that following
# either Alpaca's docs or this README works out of the box.
def _env(*names: str, default: str = "") -> str:
    for name in names:
        value = os.getenv(name)
        if value:
            return value
    return default


ALPACA_API_KEY = _env("ALPACA_API_KEY", "APCA_API_KEY_ID")
ALPACA_SECRET_KEY = _env("ALPACA_SECRET_KEY", "APCA_API_SECRET_KEY")
ALPACA_BASE_URL = _env(
    "ALPACA_BASE_URL", "APCA_API_BASE_URL", default="https://paper-api.alpaca.markets"
)
ALLOW_LIVE = os.getenv("ALLOW_LIVE", "false").strip().lower() == "true"

IS_PAPER = "paper-api.alpaca.markets" in ALPACA_BASE_URL

# Optional Telegram delivery for daily briefings.
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()

# Stock market-data feed. Free Alpaca accounts must use "iex"; the default "sip"
# feed rejects recent data with a subscription error. Upgrade to "sip" only if
# your account has the paid data subscription.
ALPACA_DATA_FEED = os.getenv("ALPACA_DATA_FEED", "iex").strip().lower()

# ---------------------------------------------------------------------------
# Global risk limits (non-negotiable)
# ---------------------------------------------------------------------------
RISK_PER_TRADE = 0.01          # 1% of equity risked per trade
MAX_PORTFOLIO_DRAWDOWN = 0.10  # close everything and halt if equity falls 10% from peak
ATR_PERIOD = 14                # ATR lookback used for position sizing
SLIPPAGE_PCT = 0.0005          # 0.05% modeled slippage per fill (used in backtest)
# Cap any single position's notional at this fraction of equity. Critical on
# short (e.g. 1-min) timeframes where ATR is tiny: risk-based sizing would
# otherwise demand a gigantic share count and blow past buying power.
MAX_POSITION_NOTIONAL_PCT = 0.10
# Also floor the stop distance at this fraction of price so 1-min noise-level
# ATR can't produce absurd size (keeps the 1%-risk math sane).
MIN_STOP_DISTANCE_PCT = 0.004  # 0.4% of price

# ---------------------------------------------------------------------------
# Strategy / instrument definitions
# ---------------------------------------------------------------------------
# Alpaca uses "BTC/USD" for crypto symbols and plain tickers for equities/ETFs.


@dataclass(frozen=True)
class InstrumentConfig:
    symbol: str
    asset_class: str          # "equity" or "crypto"
    strategy: str             # "mean_reversion" | "momentum_breakout" | "trend_following"
    timeframe: str            # human-readable, mapped to Alpaca TimeFrame in broker/data
    params: dict = field(default_factory=dict)


INSTRUMENTS: list[InstrumentConfig] = [
    InstrumentConfig(
        symbol="SPY",
        asset_class="equity",
        strategy="mean_reversion",
        timeframe="1Min",
        # OPTIMIZED: only fade WITH the higher-timeframe trend (buy dips in an
        # uptrend / short rips in a downtrend) via trend_ma, and use a wider ATR
        # stop so normal noise doesn't stop us out before price reverts to mean.
        params={
            # 1-min bars: counts rescaled to keep the SAME time window as the old
            # 15-min setup (lookback 300min = 5h mean, trend_ma 750min = 12.5h trend).
            "lookback": 300,
            "entry_std": 1.2,
            "stop_atr_mult": 2.5,
            "trend_ma": 750,
            # Profit-lock: once green, exit if price pulls back this many ATRs from
            # its best level (banks the gain when it starts rolling over).
            "profit_lock_atr_mult": 0.5,
        },
    ),
    InstrumentConfig(
        symbol="QQQ",
        asset_class="equity",
        strategy="mean_reversion",
        timeframe="1Min",
        params={
            "lookback": 300,
            "entry_std": 1.2,
            "stop_atr_mult": 2.5,
            "trend_ma": 750,
            "profit_lock_atr_mult": 0.5,
        },
    ),
    InstrumentConfig(
        symbol="GLD",
        asset_class="equity",
        strategy="trend_following",
        timeframe="4Hour",
        # OPTIMIZED: 20/50 EMA instead of 50/200. A 50/200 cross on 4h bars is far
        # too rare to fire within 6 months, so the original never traded. Faster
        # EMAs actually catch commodity trends (e.g. gold's uptrend).
        params={"fast_ema": 20, "slow_ema": 50, "trail_atr_mult": 3.0},
    ),
    InstrumentConfig(
        symbol="USO",
        asset_class="equity",
        strategy="trend_following",
        timeframe="4Hour",
        params={"fast_ema": 20, "slow_ema": 50, "trail_atr_mult": 3.0},
    ),
]

# ---------------------------------------------------------------------------
# Large-cap equity scan universe (same 1-min mean-reversion setup as SPY/QQQ).
# ---------------------------------------------------------------------------
# Add or remove tickers here to change what the bot scans. These are the most
# liquid mega-caps (tech-heavy) so IEX fills and data are reliable. All use the
# identical rescaled 1-min params: buy ~1.5-std dips WITH the ~12.5h trend, exit
# on reversion to the ~5h mean.
MEAN_REVERSION_UNIVERSE = [
    "NVDA",   # Nvidia
    "AAPL",   # Apple
    "MSFT",   # Microsoft
    "GOOGL",  # Alphabet / Google
    "AMZN",   # Amazon
    "META",   # Meta
    "TSLA",   # Tesla
    "AMD",    # AMD
    "AVGO",   # Broadcom
    "NFLX",   # Netflix
    "UNH",    # UnitedHealth
    "JPM",    # JPMorgan
    "COST",   # Costco
    "CRM",    # Salesforce
    "ORCL",   # Oracle
    # Added by momentum screen (strongest 3-month uptrends; buy dips WITH the trend).
    "MU",     # Micron
    "INTC",   # Intel
    "MRVL",   # Marvell
    "DDOG",   # Datadog
    "PANW",   # Palo Alto Networks
    "CRWD",   # CrowdStrike
    "AMAT",   # Applied Materials
    "LRCX",   # Lam Research
    "TXN",    # Texas Instruments
    "CSCO",   # Cisco
]

_MR_1MIN_PARAMS = {
    "lookback": 300,
    "entry_std": 1.2,
    "stop_atr_mult": 2.5,
    "trend_ma": 750,
    "profit_lock_atr_mult": 0.5,
}

INSTRUMENTS += [
    InstrumentConfig(
        symbol=_sym,
        asset_class="equity",
        strategy="mean_reversion",
        timeframe="1Min",
        params=dict(_MR_1MIN_PARAMS),
    )
    for _sym in MEAN_REVERSION_UNIVERSE
]

# Crypto scanned exactly like the stocks: 1-min mean reversion (buy dips WITH the
# trend, profit-lock exits). Crypto trades 24/7, so these stay active even when the
# stock market is closed (nights, weekends, holidays).
CRYPTO_MEAN_REVERSION_UNIVERSE = [
    "BTC/USD",   # Bitcoin
    "AAVE/USD",  # Aave
    "SOL/USD",   # Solana
    "UNI/USD",   # Uniswap
]

INSTRUMENTS += [
    InstrumentConfig(
        symbol=_sym,
        asset_class="crypto",
        strategy="mean_reversion",
        timeframe="1Min",
        params=dict(_MR_1MIN_PARAMS),
    )
    for _sym in CRYPTO_MEAN_REVERSION_UNIVERSE
]

# Convenience lookup by symbol.
INSTRUMENTS_BY_SYMBOL = {i.symbol: i for i in INSTRUMENTS}

# ---------------------------------------------------------------------------
# Correlation filter groups
# ---------------------------------------------------------------------------
# If every symbol in a group's "trigger" set is already long, block new longs
# on the symbols in "block".
CORRELATION_FILTER = {
    "risk_on": {"trigger": {"SPY", "QQQ"}, "block": {"BTC/USD"}},
}

# ---------------------------------------------------------------------------
# Loop cadence
# ---------------------------------------------------------------------------
# How often the main loop wakes up (seconds). Each strategy only acts when a new
# candle of its timeframe has closed, tracked in main.py. Used only when
# ALIGN_TO_CANDLE_CLOSE is False.
LOOP_INTERVAL_SECONDS = 60

# Instead of a fixed sleep at a random phase, wake a few seconds AFTER each minute
# boundary so we act on a freshly-closed candle within ~CANDLE_CLOSE_BUFFER_SECONDS
# (vs up to 60s of lag). All timeframes (1Min/1Hour/4Hour) close on minute
# boundaries, so minute alignment covers them all. No extra API load.
ALIGN_TO_CANDLE_CLOSE = True
CANDLE_CLOSE_BUFFER_SECONDS = 3  # let Alpaca finish aggregating the just-closed bar

# File outputs
TRADES_CSV = "trades.csv"
DAILY_PNL_CSV = "daily_pnl.csv"
BACKTEST_CHART = "backtest_results.png"


def validate_credentials() -> None:
    """Raise a clear error if keys are missing or live trading is unsafely enabled."""
    if not ALPACA_API_KEY or not ALPACA_SECRET_KEY:
        raise RuntimeError(
            "Missing ALPACA_API_KEY / ALPACA_SECRET_KEY. "
            "Copy .env.example to .env and fill in your keys."
        )
    if not IS_PAPER and not ALLOW_LIVE:
        raise RuntimeError(
            "LIVE endpoint detected but ALLOW_LIVE is not 'true'. Refusing to trade "
            "real money. Set ALLOW_LIVE=true in .env only after successful paper trading."
        )
