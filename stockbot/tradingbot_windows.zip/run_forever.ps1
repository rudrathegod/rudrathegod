# 24/7 supervisor for the paper trading bot (Windows / PowerShell).
# - Auto-restarts the bot if it crashes (after a short backoff).
# - Does NOT restart on breaker halt (exit code 42) or clean stop (exit 0).
# Run from the project folder:
#     powershell -ExecutionPolicy Bypass -File .\run_forever.ps1
Set-Location -Path $PSScriptRoot
if (-not (Test-Path "logs")) { New-Item -ItemType Directory -Path "logs" | Out-Null }

while ($true) {
    "[start $(Get-Date -Format o)]" | Out-File -Append -Encoding utf8 logs\bot.out
    & ".\.venv\Scripts\python.exe" -m bot.main *>> logs\bot.out
    $code = $LASTEXITCODE
    "[exit code=$code $(Get-Date -Format o)]" | Out-File -Append -Encoding utf8 logs\bot.out

    if ($code -eq 42) {
        "[HALT] Drawdown circuit breaker tripped. NOT restarting. Review, then relaunch." | Out-File -Append -Encoding utf8 logs\bot.out
        break
    }
    if ($code -eq 0) {
        "[STOP] Clean exit (e.g. Ctrl-C). NOT restarting." | Out-File -Append -Encoding utf8 logs\bot.out
        break
    }
    "[restart] Unexpected exit ($code); restarting in 10s..." | Out-File -Append -Encoding utf8 logs\bot.out
    Start-Sleep -Seconds 10
}
